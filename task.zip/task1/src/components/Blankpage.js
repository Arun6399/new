import React from "react";

function Blankpage() {
  return <h1>Blankpage</h1>;
}

export default Blankpage;
